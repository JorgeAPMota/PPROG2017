package datagui.ui;

import javax.swing.*;

public class Janela extends JFrame {

    public Janela() {
        
    }

}
