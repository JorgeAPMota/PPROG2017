package datagui.ui;

public class Main {

    public static void main(String[] args) {
        Janela j = new Janela();
    }

}

